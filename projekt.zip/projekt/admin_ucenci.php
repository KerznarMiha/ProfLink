<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "profLink";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Fetch students data
$students = [];
$sql = "SELECT * FROM students";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }
}

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? '';
    $studentName = $_POST['studentName'] ?? '';
    $studentEmail = $_POST['studentEmail'] ?? '';
    $studentPassword = $_POST['studentPassword'] ?? '';
    $studentSubjects = $_POST['studentSubjects'] ?? '';

    if ($action === 'add') {
        // Hash the password before storing it
        $hashedPassword = password_hash($studentPassword, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO students (name, email, password, subjects) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $studentName, $studentEmail, $hashedPassword, $studentSubjects);
        $stmt->execute();
    } elseif ($action === 'edit') {
        $studentId = $_POST['studentId'];
        if (!empty($studentPassword)) {
            // Update with password hash if password is provided
            $hashedPassword = password_hash($studentPassword, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE students SET name = ?, email = ?, password = ?, subjects = ? WHERE id = ?");
            $stmt->bind_param("ssssi", $studentName, $studentEmail, $hashedPassword, $studentSubjects, $studentId);
        } else {
            // Update without changing password
            $stmt = $conn->prepare("UPDATE students SET name = ?, email = ?, subjects = ? WHERE id = ?");
            $stmt->bind_param("sssi", $studentName, $studentEmail, $studentSubjects, $studentId);
        }
        $stmt->execute();
    } elseif ($action === 'delete') {
        $studentId = $_POST['studentId'];
        $stmt = $conn->prepare("DELETE FROM students WHERE id = ?");
        $stmt->bind_param("i", $studentId);
        $stmt->execute();
    }
    header("Location: admin_ucenci.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Učenci - Administrator</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 0; color: #333; height: 100vh; display: flex; }
        .dashboard { display: flex; width: 100%; height: 100vh; }
        .sidebar { width: 250px; background-color: #007bff; padding: 20px; color: #fff; display: flex; flex-direction: column; }
        .sidebar h2 { margin-bottom: 20px; text-align: center; }
        .sidebar ul { list-style-type: none; padding: 0; }
        .sidebar ul li { margin: 15px 0; }
        .sidebar ul li a { color: #fff; text-decoration: none; font-size: 18px; padding: 10px; border-radius: 8px; display: block; transition: background-color 0.3s; text-align: center; }
        .sidebar ul li a.active, .sidebar ul li a:hover { background-color: #0056b3; }
        .main-content { flex-grow: 1; padding: 30px; background-color: #ffffff; overflow-y: auto; border-radius: 12px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); margin: 20px; }
        h1 { font-size: 24px; font-weight: bold; color: #333; margin-bottom: 20px; }
        .add-button { background-color: #007bff; color: #fff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; transition: background-color 0.3s; display: inline-block; margin-bottom: 20px; }
        .add-button:hover { background-color: #0056b3; }
        .form-group { margin-bottom: 15px; }
        .form-group label { font-weight: bold; color: #555; display: block; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 10px; font-size: 16px; border: 1px solid #ddd; border-radius: 6px; }
        .submit-button, .cancel-button { padding: 10px 15px; font-size: 14px; color: #fff; border: none; border-radius: 6px; cursor: pointer; margin-top: 10px; }
        .submit-button { background-color: #007bff; }
        .cancel-button { background-color: #6c757d; }
        .subjects-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .subjects-table th, .subjects-table td { padding: 15px; text-align: left; border-bottom: 1px solid #ddd; }
        .subjects-table th { background-color: #f1f1f1; font-weight: bold; }
        .edit-button { background-color: #28a745; color: #fff; padding: 8px 12px; border: none; border-radius: 4px; cursor: pointer; }
        .edit-button:hover { background-color: #218838; }
        .red-delete-button { background-color: #dc3545; color: #fff; padding: 8px 12px; border: none; border-radius: 4px; cursor: pointer; margin-left: 10px; }
        .red-delete-button:hover { background-color: #c82333; }
        .form-container { display: none; margin-bottom: 20px; background-color: #f8f9fa; padding: 20px; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Administrator</h2>
            <ul>
                <li><a href="admin_predmeti.php"><i class="icon">&#x1F4D6;</i> Predmeti</a></li>
                <li><a href="admin_ucitelji.php"><i class="icon">&#x1F464;</i> Učitelji</a></li>
                <li><a href="admin_ucenci.php" class="active"><i class="icon">&#x1F393;</i> Učenci</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <h1>Učenci - Upravljanje</h1>
            <button class="add-button" onclick="showAddStudentForm()">+ Dodaj učenca</button>

            <!-- Student Form -->
            <div class="form-container" id="studentForm">
                <form method="POST">
                    <input type="hidden" name="action" id="action" value="add">
                    <input type="hidden" name="studentId" id="studentId">
                    <div class="form-group">
                        <label for="studentName">Ime Učenca:</label>
                        <input type="text" name="studentName" id="studentName" required>
                    </div>
                    <div class="form-group">
                        <label for="studentEmail">Email:</label>
                        <input type="email" name="studentEmail" id="studentEmail" required>
                    </div>
                    <div class="form-group">
                        <label for="studentPassword">Geslo:</label>
                        <input type="password" name="studentPassword" id="studentPassword">
                    </div>
                    <div class="form-group">
                        <label for="studentSubjects">Predmeti:</label>
                        <input type="text" name="studentSubjects" id="studentSubjects" placeholder="Ločite predmete z vejicami">
                    </div>
                    <button type="submit" class="submit-button">Shrani</button>
                    <button type="button" class="cancel-button" onclick="hideStudentForm()">Prekliči</button>
                </form>
            </div>

            <!-- Students Table -->
            <table class="subjects-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ime Učenca</th>
                        <th>Email</th>
                        <th>Predmeti</th>
                        <th>Dejanja</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($student['id']); ?></td>
                        <td><?php echo htmlspecialchars($student['name']); ?></td>
                        <td><?php echo htmlspecialchars($student['email']); ?></td>
                        <td><?php echo htmlspecialchars($student['subjects']); ?></td>
                        <td>
                            <button class="edit-button" onclick="editStudent(<?php echo $student['id']; ?>, '<?php echo htmlspecialchars($student['name']); ?>', '<?php echo htmlspecialchars($student['email']); ?>', '<?php echo htmlspecialchars($student['subjects']); ?>')">Uredi</button>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="studentId" value="<?php echo $student['id']; ?>">
                                <button type="submit" class="red-delete-button">Izbriši</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function showAddStudentForm() {
            document.getElementById('studentForm').style.display = 'block';
            document.getElementById('action').value = 'add';
            document.getElementById('studentId').value = '';
            document.getElementById('studentName').value = '';
            document.getElementById('studentEmail').value = '';
            document.getElementById('studentPassword').value = '';
            document.getElementById('studentSubjects').value = '';
        }

        function editStudent(id, name, email, subjects) {
            document.getElementById('studentForm').style.display = 'block';
            document.getElementById('action').value = 'edit';
            document.getElementById('studentId').value = id;
            document.getElementById('studentName').value = name;
            document.getElementById('studentEmail').value = email;
            document.getElementById('studentPassword').value = '';  // Leave password blank for security
            document.getElementById('studentSubjects').value = subjects;
        }

        function hideStudentForm() {
            document.getElementById('studentForm').style.display = 'none';
        }
    </script>
</body>
</html>
