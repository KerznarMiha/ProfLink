<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "profLink";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Povezava z bazo ni uspela: " . $conn->connect_error);
}

$email = $password = "";
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Hardcoded example credentials (replace this for production)
    if ($email === "user" && $password === "user") {
        // Set session variable to indicate a logged-in state
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = "Admin"; // Store username or other user info as needed

        // Redirect to the admin dashboard
        header("Location: admin_predmeti.php");
        exit();
    } else {
        // Display an error message if credentials are incorrect
        $error_message = "Napačen uporabniško ime ali geslo.";
    }
}
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prijava - E-učilnica Profilink</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>E-učilnica Profilink Administrator</h1>
        </div>
        <div class="login-form">
            <form action="" method="post">
                <label for="email">Uporabniško ime</label>
                <input type="text" id="email" name="email" placeholder="Vnesite svoje uporabniško ime" required value="<?php echo htmlspecialchars($email); ?>">
                
                <label for="password">Geslo</label>
                <input type="password" id="password" name="password" placeholder="Vnesite svoje geslo" required>
                
                <div class="checkbox-container">
                    <input type="checkbox" id="stay-logged-in" name="stay-logged-in">
                    <label for="stay-logged-in">Ostanite prijavljeni</label>
                </div>
                
                <button type="submit">PRIJAVA</button>
                
                <?php if ($error_message): ?>
                    <div class="error-message"><?php echo $error_message; ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</body>
</html>
