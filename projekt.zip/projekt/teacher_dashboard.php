<?php
session_start();
if (!isset($_SESSION['teacher_loggedin']) || $_SESSION['teacher_loggedin'] !== true) {
    header("Location: teacher_login.php");
    exit();
}

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nadzorna plošča - Učitelj</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            height: 100vh;
            overflow: hidden;
            margin: 0;
            color: #333;
        }

        .dashboard {
            display: flex;
            width: 100%;
        }

        .sidebar {
            width: 250px;
            background-color: #007bff;
            padding: 20px;
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            width: 100%;
            padding: 0;
        }

        .sidebar ul li {
            width: 100%;
            margin: 15px 0;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            padding: 10px;
            border-radius: 8px;
            display: block;
            transition: background-color 0.3s;
            text-align: center;
        }

        .sidebar ul li a.active, .sidebar ul li a:hover {
            background-color: #0056b3;
        }

        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #ffffff;
            overflow-y: auto;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .section-header {
            font-size: 26px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .welcome-message {
            font-size: 18px;
            color: #555;
            margin-top: 15px;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Učitelj</h2>
            <ul>
                <li><a href="teacher_dashboard.php" class="active"><i class="icon">&#x1F4C8;</i> Nadzorna plošča</a></li>
                <li><a href="teacher_materials.php"><i class="icon">&#x1F4D6;</i> Gradivo</a></li>
                <li><a href="teacher_assignments.php"><i class="icon">&#x1F4C4;</i> Oddane naloge</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="section-header">Nadzorna plošča - Dobrodošli, <?php echo htmlspecialchars($username); ?>!</div>
            <p class="welcome-message">
                Izberite možnost na levi za nalaganje in pregled gradiv ali pregled oddanih nalog učencev.<br><br>
                Kot učitelj imate naslednje možnosti:
                <ul>
                    <li>Dodajanje in brisanje gradiv za predmete, ki jih poučujete.</li>
                    <li>Pregledovanje nalog, ki so jih učenci oddali za izbrane predmete.</li>
                </ul>
                Ta nadzorna plošča vam omogoča enostavno upravljanje vseh nalog in gradiv, povezanih s poučevanjem.
            </p>
        </div>
    </div>
</body>
</html>
