// General Modal Handling Functions

// Open Teacher Modal
function openTeacherModal(mode = 'add', id = null) {
    const modal = document.getElementById('teacherModal');
    const modalTitle = document.getElementById('teacherModalTitle');
    modal.style.display = 'block';

    if (mode === 'edit') {
        modalTitle.innerText = 'Uredi Učitelja';
        // Placeholder for loading existing teacher data by ID
        // fetchTeacherData(id);
    } else {
        modalTitle.innerText = 'Dodaj Učitelja';
        document.getElementById('teacherForm').reset();
    }
}

// Close Teacher Modal
function closeTeacherModal() {
    document.getElementById('teacherModal').style.display = 'none';
}

// Open Student Modal
function openStudentModal(mode = 'add', id = null) {
    const modal = document.getElementById('studentModal');
    const modalTitle = document.getElementById('studentModalTitle');
    modal.style.display = 'block';

    if (mode === 'edit') {
        modalTitle.innerText = 'Uredi Učenca';
        // Placeholder for loading existing student data by ID
        // fetchStudentData(id);
    } else {
        modalTitle.innerText = 'Dodaj Učenca';
        document.getElementById('studentForm').reset();
    }
}

// Close Student Modal
function closeStudentModal() {
    document.getElementById('studentModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const teacherModal = document.getElementById('teacherModal');
    const studentModal = document.getElementById('studentModal');
    if (event.target == teacherModal) {
        closeTeacherModal();
    }
    if (event.target == studentModal) {
        closeStudentModal();
    }
}

// CRUD Functions for Teachers and Students

// Delete Teacher
function deleteTeacher(id) {
    if (confirm('Ste prepričani, da želite izbrisati tega učitelja?')) {
        // Placeholder alert for deletion (replace with actual AJAX request)
        alert('Učitelj je bil izbrisan.');
        // Example AJAX request:
        // deleteTeacherFromDatabase(id);
    }
}

// Delete Student
function deleteStudent(id) {
    if (confirm('Ste prepričani, da želite izbrisati tega učenca?')) {
        // Placeholder alert for deletion (replace with actual AJAX request)
        alert('Učenec je bil izbrisan.');
        // Example AJAX request:
        // deleteStudentFromDatabase(id);
    }
}

// Form Submission for Adding/Editing Teacher
document.getElementById('teacherForm').onsubmit = function(event) {
    event.preventDefault();
    const teacherName = document.getElementById('teacherName').value;
    const teacherSubjects = document.getElementById('teacherSubjects').value;
    const mode = document.getElementById('teacherModalTitle').innerText === 'Dodaj Učitelja' ? 'add' : 'edit';

    if (mode === 'add') {
        alert(`Učitelj ${teacherName} je bil dodan z predmeti: ${teacherSubjects}.`);
        // Add teacher to database
        // addTeacherToDatabase({ name: teacherName, subjects: teacherSubjects });
    } else {
        alert(`Učitelj ${teacherName} je bil posodobljen z novimi predmeti: ${teacherSubjects}.`);
        // Update teacher in database
        // updateTeacherInDatabase({ id: teacherId, name: teacherName, subjects: teacherSubjects });
    }
    closeTeacherModal();
};

// Form Submission for Adding/Editing Student
document.getElementById('studentForm').onsubmit = function(event) {
    event.preventDefault();
    const studentName = document.getElementById('studentName').value;
    const studentSubjects = document.getElementById('studentSubjects').value;
    const mode = document.getElementById('studentModalTitle').innerText === 'Dodaj Učenca' ? 'add' : 'edit';

    if (mode === 'add') {
        alert(`Učenec ${studentName} je bil dodan z predmeti: ${studentSubjects}.`);
        // Add student to database
        // addStudentToDatabase({ name: studentName, subjects: studentSubjects });
    } else {
        alert(`Učenec ${studentName} je bil posodobljen z novimi predmeti: ${studentSubjects}.`);
        // Update student in database
        // updateStudentInDatabase({ id: studentId, name: studentName, subjects: studentSubjects });
    }
    closeStudentModal();
};

// Placeholder AJAX functions (these would need to be replaced with actual API calls)

function addTeacherToDatabase(teacherData) {
    fetch('/api/teachers', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(teacherData),
    })
    .then(response => response.json())
    .then(data => alert('Učitelj je bil uspešno dodan.'))
    .catch(error => console.error('Napaka:', error));
}

function updateTeacherInDatabase(teacherData) {
    fetch(`/api/teachers/${teacherData.id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(teacherData),
    })
    .then(response => response.json())
    .then(data => alert('Učitelj je bil uspešno posodobljen.'))
    .catch(error => console.error('Napaka:', error));
}

function deleteTeacherFromDatabase(id) {
    fetch(`/api/teachers/${id}`, {
        method: 'DELETE',
    })
    .then(response => response.json())
    .then(data => alert('Učitelj je bil uspešno izbrisan.'))
    .catch(error => console.error('Napaka:', error));
}

function addStudentToDatabase(studentData) {
    fetch('/api/students', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(studentData),
    })
    .then(response => response.json())
    .then(data => alert('Učenec je bil uspešno dodan.'))
    .catch(error => console.error('Napaka:', error));
}

function updateStudentInDatabase(studentData) {
    fetch(`/api/students/${studentData.id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(studentData),
    })
    .then(response => response.json())
    .then(data => alert('Učenec je bil uspešno posodobljen.'))
    .catch(error => console.error('Napaka:', error));
}

function deleteStudentFromDatabase(id) {
    fetch(`/api/students/${id}`, {
        method: 'DELETE',
    })
    .then(response => response.json())
    .then(data => alert('Učenec je bil uspešno izbrisan.'))
    .catch(error => console.error('Napaka:', error));
}
