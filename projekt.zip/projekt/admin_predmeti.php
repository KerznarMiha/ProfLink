<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "profLink";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Fetch subjects data
$subjects = [];
$sql = "SELECT * FROM subject"; // Changed to `subject`
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $subjects[] = $row;
    }
}

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST['action'] ?? '';
    $subjectName = $_POST['subjectName'] ?? '';
    $subjectDescription = $_POST['subjectDescription'] ?? '';

    if ($action === 'add') {
        $stmt = $conn->prepare("INSERT INTO subject (name, description) VALUES (?, ?)"); // Changed to `subject`
        $stmt->bind_param("ss", $subjectName, $subjectDescription);
        $stmt->execute();
    } elseif ($action === 'edit') {
        $subjectId = $_POST['subjectId'];
        $stmt = $conn->prepare("UPDATE subject SET name = ?, description = ? WHERE id = ?"); // Changed to `subject`
        $stmt->bind_param("ssi", $subjectName, $subjectDescription, $subjectId);
        $stmt->execute();
    } elseif ($action === 'delete') {
        $subjectId = $_POST['subjectId'];
        $stmt = $conn->prepare("DELETE FROM subject WHERE id = ?"); // Changed to `subject`
        $stmt->bind_param("i", $subjectId);
        $stmt->execute();
    }
    header("Location: admin_predmeti.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Predmeti - Administrator</title>
    <style>
        /* Same styling as in the teacher page */
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; background-color: #f4f4f9; margin: 0; color: #333; height: 100vh; display: flex; }
        .dashboard { display: flex; width: 100%; height: 100vh; }
        .sidebar { width: 250px; background-color: #007bff; padding: 20px; color: #fff; display: flex; flex-direction: column; }
        .sidebar h2 { margin-bottom: 20px; text-align: center; }
        .sidebar ul { list-style-type: none; padding: 0; }
        .sidebar ul li { margin: 15px 0; }
        .sidebar ul li a { color: #fff; text-decoration: none; font-size: 18px; padding: 10px; border-radius: 8px; display: block; transition: background-color 0.3s; text-align: center; }
        .sidebar ul li a.active, .sidebar ul li a:hover { background-color: #0056b3; }
        .main-content { flex-grow: 1; padding: 30px; background-color: #ffffff; overflow-y: auto; border-radius: 12px; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1); margin: 20px; }
        h1 { font-size: 24px; font-weight: bold; color: #333; margin-bottom: 20px; }
        .add-button { background-color: #007bff; color: #fff; font-size: 16px; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; transition: background-color 0.3s; display: inline-block; margin-bottom: 20px; }
        .add-button:hover { background-color: #0056b3; }
        .form-group { margin-bottom: 15px; }
        .form-group label { font-weight: bold; color: #555; display: block; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 10px; font-size: 16px; border: 1px solid #ddd; border-radius: 6px; }
        .submit-button, .cancel-button { padding: 10px 15px; font-size: 14px; color: #fff; border: none; border-radius: 6px; cursor: pointer; margin-top: 10px; }
        .submit-button { background-color: #007bff; }
        .cancel-button { background-color: #6c757d; }
        .subjects-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .subjects-table th, .subjects-table td { padding: 15px; text-align: left; border-bottom: 1px solid #ddd; }
        .subjects-table th { background-color: #f1f1f1; font-weight: bold; }
        .edit-button { background-color: #28a745; color: #fff; padding: 8px 12px; border: none; border-radius: 4px; cursor: pointer; }
        .edit-button:hover { background-color: #218838; }
        .red-delete-button { background-color: #dc3545; color: #fff; padding: 8px 12px; border: none; border-radius: 4px; cursor: pointer; margin-left: 10px; }
        .red-delete-button:hover { background-color: #c82333; }
        .form-container { display: none; margin-bottom: 20px; background-color: #f8f9fa; padding: 20px; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Administrator</h2>
            <ul>
                <li><a href="admin_predmeti.php" class="active"><i class="icon">&#x1F4D6;</i> Predmeti</a></li>
                <li><a href="admin_ucitelji.php"><i class="icon">&#x1F464;</i> Učitelji</a></li>
                <li><a href="admin_ucenci.php"><i class="icon">&#x1F393;</i> Učenci</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <h1>Predmeti - Upravljanje</h1>
            <button class="add-button" onclick="showAddSubjectForm()">+ Dodaj predmet</button>

            <!-- Subject Form -->
            <div class="form-container" id="subjectForm">
                <form method="POST">
                    <input type="hidden" name="action" id="action" value="add">
                    <input type="hidden" name="subjectId" id="subjectId">
                    <div class="form-group">
                        <label for="subjectName">Ime Predmeta:</label>
                        <input type="text" name="subjectName" id="subjectName" required>
                    </div>
                    <div class="form-group">
                        <label for="subjectDescription">Opis:</label>
                        <input type="text" name="subjectDescription" id="subjectDescription" required>
                    </div>
                    <button type="submit" class="submit-button">Shrani</button>
                    <button type="button" class="cancel-button" onclick="hideSubjectForm()">Prekliči</button>
                </form>
            </div>

            <!-- Subjects Table -->
            <table class="subjects-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ime Predmeta</th>
                        <th>Opis</th>
                        <th>Dejanja</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($subjects as $subject): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($subject['id']); ?></td>
                        <td><?php echo htmlspecialchars($subject['name']); ?></td>
                        <td><?php echo htmlspecialchars($subject['description']); ?></td>
                        <td>
                            <button class="edit-button" onclick="editSubject(<?php echo $subject['id']; ?>, '<?php echo htmlspecialchars($subject['name']); ?>', '<?php echo htmlspecialchars($subject['description']); ?>')">Uredi</button>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="subjectId" value="<?php echo $subject['id']; ?>">
                                <button type="submit" class="red-delete-button">Izbriši</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function showAddSubjectForm() {
            document.getElementById('subjectForm').style.display = 'block';
            document.getElementById('action').value = 'add';
            document.getElementById('subjectId').value = '';
            document.getElementById('subjectName').value = '';
            document.getElementById('subjectDescription').value = '';
        }

        function editSubject(id, name, description) {
            document.getElementById('subjectForm').style.display = 'block';
            document.getElementById('action').value = 'edit';
            document.getElementById('subjectId').value = id;
            document.getElementById('subjectName').value = name;
            document.getElementById('subjectDescription').value = description;
        }

        function hideSubjectForm() {
            document.getElementById('subjectForm').style.display = 'none';
        }
    </script>
</body>
</html>
