<?php
session_start();

// Simulating a simple teacher login check. Adjust as needed.
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'teacher') {
    // Redirect to the login page if not logged in or if not a teacher
    header("Location: admin_login.php");
    exit();
}

// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "profLink";

// Connect to the database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch subjects assigned to this teacher, adjust query as needed
$teacherId = $_SESSION['teacher_id'] ?? 0;
$subjects = [];
$sql = "SELECT * FROM subjects WHERE teacher_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $teacherId);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $subjects[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher View</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="dashboard">
        <h1>Teacher Dashboard</h1>
        <p>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></p>

        <h2>Your Subjects</h2>
        <?php if (count($subjects) > 0): ?>
            <ul>
                <?php foreach ($subjects as $subject): ?>
                    <li><?php echo htmlspecialchars($subject['name']); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No subjects assigned.</p>
        <?php endif; ?>
    </div>
</body>
</html>
