<?php
session_start();
if (!isset($_SESSION['student_loggedin']) || $_SESSION['student_loggedin'] !== true) {
    header("Location: student_login.php");
    exit();
}

$username = $_SESSION['username'];

// Placeholder: You would fetch the subjects and materials from the database based on student preferences
// For this example, we're using a static list of materials
$materials = [
    "Matematika" => ["Matematika - Poglavje 1.pdf", "Matematika - Poglavje 2.pdf"],
    "Fizika" => ["Fizika - Poglavje 1.pdf", "Fizika - Poglavje 2.pdf"],
    "Kemija" => ["Kemija - Poglavje 1.pdf", "Kemija - Poglavje 2.pdf"]
];
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moja Gradiva - Učenec</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            height: 100vh;
            overflow: hidden;
            margin: 0;
            color: #333;
        }

        .dashboard {
            display: flex;
            width: 100%;
        }

        .sidebar {
            width: 250px;
            background-color: #28a745;
            padding: 20px;
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            width: 100%;
            padding: 0;
        }

        .sidebar ul li {
            width: 100%;
            margin: 15px 0;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            padding: 10px;
            border-radius: 8px;
            display: block;
            transition: background-color 0.3s;
            text-align: center;
        }

        .sidebar ul li a.active, .sidebar ul li a:hover {
            background-color: #1e7a34;
        }

        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #ffffff;
            overflow-y: auto;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .section-header {
            font-size: 26px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .materials-list {
            margin-top: 15px;
        }

        .subject {
            margin-bottom: 20px;
        }

        .subject h3 {
            font-size: 20px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .subject ul {
            list-style-type: none;
            padding: 0;
        }

        .subject ul li {
            margin-bottom: 8px;
        }

        .subject ul li a {
            text-decoration: none;
            color: #007bff;
            transition: color 0.3s;
        }

        .subject ul li a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Učenec</h2>
            <ul>
                <li><a href="student_dashboard.php"><i class="icon">&#x1F4C8;</i> Nadzorna plošča</a></li>
                <li><a href="student_profile.php"><i class="icon">&#x1F4DD;</i> Profil</a></li>
                <li><a href="student_materials.php" class="active"><i class="icon">&#x1F4D6;</i> Moja Gradiva</a></li>
                <li><a href="student_assignments.php"><i class="icon">&#x1F4C4;</i> Moje Naloge</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="section-header">Gradiva za izbrane predmete - Dobrodošli, <?php echo htmlspecialchars($username); ?></div>
            <p>Spodaj so na voljo gradiva za predmete, ki jih obiskujete:</p>

            <div class="materials-list">
                <?php foreach ($materials as $subject => $files): ?>
                    <div class="subject">
                        <h3><?php echo htmlspecialchars($subject); ?></h3>
                        <ul>
                            <?php foreach ($files as $file): ?>
                                <li><a href="materials/<?php echo urlencode($file); ?>" download><?php echo htmlspecialchars($file); ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html>
