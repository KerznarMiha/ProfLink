<?php
session_start();
if (!isset($_SESSION['student_loggedin']) || $_SESSION['student_loggedin'] !== true) {
    header("Location: student_login.php");
    exit();
}

$username = $_SESSION['username'];
$upload_message = "";

// Handle file upload
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = $_POST['subject'];
    $assignment_title = $_POST['assignment_title'];
    $student_name = $_SESSION['username'];
    
    // Create a safe filename with format "Surname Name – Assignment Title"
    $file_name = $student_name . " – " . $assignment_title . "." . pathinfo($_FILES['assignment']['name'], PATHINFO_EXTENSION);
    $target_dir = "uploads/assignments/";
    $target_file = $target_dir . $file_name;

    // Check if file already exists
    if (file_exists($target_file)) {
        if (isset($_POST['confirm_overwrite']) && $_POST['confirm_overwrite'] == "yes") {
            // Overwrite the file if confirmed
            if (move_uploaded_file($_FILES['assignment']['tmp_name'], $target_file)) {
                $upload_message = "Datoteka je uspešno posodobljena.";
            } else {
                $upload_message = "Pri nalaganju datoteke je prišlo do napake.";
            }
        } else {
            $upload_message = "Datoteka že obstaja. Potrdite prepis.";
        }
    } else {
        // Move file to target directory
        if (move_uploaded_file($_FILES['assignment']['tmp_name'], $target_file)) {
            $upload_message = "Datoteka je uspešno naložena.";
        } else {
            $upload_message = "Pri nalaganju datoteke je prišlo do napake.";
        }
    }
}

// Placeholder: List of subjects the student is enrolled in
$subjects = ["Matematika", "Fizika", "Kemija"];
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moje Naloge - Učenec</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            height: 100vh;
            overflow: hidden;
            margin: 0;
            color: #333;
        }

        .dashboard {
            display: flex;
            width: 100%;
        }

        .sidebar {
            width: 250px;
            background-color: #28a745;
            padding: 20px;
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            width: 100%;
            padding: 0;
        }

        .sidebar ul li {
            width: 100%;
            margin: 15px 0;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            padding: 10px;
            border-radius: 8px;
            display: block;
            transition: background-color 0.3s;
            text-align: center;
        }

        .sidebar ul li a.active, .sidebar ul li a:hover {
            background-color: #1e7a34;
        }

        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #ffffff;
            overflow-y: auto;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .section-header {
            font-size: 26px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .submit-button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .submit-button:hover {
            background-color: #1e7a34;
        }

        .upload-message {
            margin-top: 15px;
            font-size: 16px;
            color: #ff0000;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Učenec</h2>
            <ul>
                <li><a href="student_dashboard.php"><i class="icon">&#x1F4C8;</i> Nadzorna plošča</a></li>
                <li><a href="student_profile.php"><i class="icon">&#x1F4DD;</i> Profil</a></li>
                <li><a href="student_materials.php"><i class="icon">&#x1F4D6;</i> Moja Gradiva</a></li>
                <li><a href="student_assignments.php" class="active"><i class="icon">&#x1F4C4;</i> Moje Naloge</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="section-header">Oddaja nalog - Dobrodošli, <?php echo htmlspecialchars($username); ?></div>
            <form action="student_assignments.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="subject">Izberite predmet:</label>
                    <select id="subject" name="subject" required>
                        <?php foreach ($subjects as $subject): ?>
                            <option value="<?php echo htmlspecialchars($subject); ?>"><?php echo htmlspecialchars($subject); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="assignment_title">Naslov naloge:</label>
                    <input type="text" id="assignment_title" name="assignment_title" required>
                </div>

                <div class="form-group">
                    <label for="assignment">Izberite datoteko za oddajo:</label>
                    <input type="file" id="assignment" name="assignment" required>
                </div>

                <?php if ($upload_message === "Datoteka že obstaja. Potrdite prepis."): ?>
                    <div class="form-group">
                        <label>Datoteka že obstaja. Ali želite prepisati?</label>
                        <input type="checkbox" name="confirm_overwrite" value="yes"> Da, potrjujem prepis
                    </div>
                <?php endif; ?>

                <button type="submit" class="submit-button">Oddaj nalogo</button>

                <?php if ($upload_message): ?>
                    <div class="upload-message"><?php echo htmlspecialchars($upload_message); ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</body>
</html>
