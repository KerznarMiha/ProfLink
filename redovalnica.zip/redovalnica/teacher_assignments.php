<?php
session_start();
if (!isset($_SESSION['teacher_loggedin']) || $_SESSION['teacher_loggedin'] !== true) {
    header("Location: teacher_login.php");
    exit();
}

// Example assignments data (replace with dynamic content from your database)
$assignments = [
    ["subject" => "Physics", "student" => "Janez Novak", "file" => "Homework1.pdf"],
    ["subject" => "Mathematics", "student" => "Maja Kovač", "file" => "Assignment2.pdf"],
];
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Oddane naloge - Upravljanje</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            height: 100vh;
            overflow: hidden;
            margin: 0;
            color: #333;
        }

        .dashboard {
            display: flex;
            width: 100%;
        }

        .sidebar {
            width: 250px;
            background-color: #654321; /* Dark brown */
            padding: 20px;
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            width: 100%;
            padding: 0;
        }

        .sidebar ul li {
            width: 100%;
            margin: 15px 0;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            padding: 10px;
            border-radius: 8px;
            display: block;
            transition: background-color 0.3s;
            text-align: center;
        }

        .sidebar ul li a.active, .sidebar ul li a:hover {
            background-color: #8B4513; /* Light brown for active and hover */
        }

        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #ffffff;
            overflow-y: auto;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .section-header {
            font-size: 26px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #8B4513; /* Saddle brown */
            padding-bottom: 5px;
        }

        .assignments-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }

        .assignments-table th, .assignments-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .assignments-table th {
            background-color: #8B4513; /* Saddle brown */
            color: #fff;
            font-weight: bold;
        }

        .assignments-table tr:nth-child(even) {
            background-color: #f4e4d4; /* Light beige for row stripes */
        }

        .assignments-table tr:hover {
            background-color: #e0c8a7; /* Soft beige for hover effect */
        }

        .file-link {
            color: #8B4513; /* Saddle brown for links */
            text-decoration: none;
            font-weight: bold;
        }

        .file-link:hover {
            text-decoration: underline;
        }
</style>

    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Učitelj</h2>
            <ul>
                <li><a href="teacher_dashboard.php"><i class="icon">&#x1F4C8;</i> Nadzorna plošča</a></li>
                <li><a href="teacher_materials.php"><i class="icon">&#x1F4D6;</i> Gradivo</a></li>
                <li><a href="teacher_assignments.php" class="active"><i class="icon">&#x1F4C4;</i> Oddane naloge</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="section-header">Oddane naloge</div>
            
            <table class="assignments-table">
                <thead>
                    <tr>
                        <th>Predmet</th>
                        <th>Učenec</th>
                        <th>Datoteka</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($assignments as $assignment): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($assignment['subject']); ?></td>
                        <td><?php echo htmlspecialchars($assignment['student']); ?></td>
                        <td><a href="uploads/<?php echo htmlspecialchars($assignment['file']); ?>" class="file-link" download><?php echo htmlspecialchars($assignment['file']); ?></a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
