<?php
session_start();
if (!isset($_SESSION['teacher_loggedin']) || $_SESSION['teacher_loggedin'] !== true) {
    header("Location: teacher_login.php");
    exit();
}

$subjects = ["Mathematics", "Physics", "Chemistry", "Biology"]; // Replace with dynamic list if available
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gradivo - Upravljanje</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        /* Base styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f0; /* Light beige background */
            display: flex;
            height: 100vh;
            overflow: hidden;
            margin: 0;
            color: #333;
        }

        .dashboard {
            display: flex;
            width: 100%;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #654321; /* Dark brown */
            padding: 20px;
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .sidebar h2 {
            margin-bottom: 20px;
            color: #fff;
        }

        .sidebar ul {
            list-style-type: none;
            width: 100%;
            padding: 0;
        }

        .sidebar ul li {
            width: 100%;
            margin: 15px 0;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            padding: 10px;
            border-radius: 8px;
            display: block;
            transition: background-color 0.3s;
            text-align: center;
        }

        .sidebar ul li a.active, .sidebar ul li a:hover {
            background-color: #8B4513; /* Saddle brown for active and hover */
        }

        /* Main Content */
        .main-content {
            flex-grow: 1;
            padding: 30px;
            background-color: #ffffff;
            overflow-y: auto;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .section-header {
            font-size: 26px;
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
            border-bottom: 2px solid #8B4513; /* Saddle brown underline */
            padding-bottom: 5px;
        }

        /* Form Container */
        .form-container {
            background-color: #f0e6d6; /* Light beige */
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .form-container label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
            color: #5C4033; /* Dark brown text */
        }

        .form-container select,
        .form-container input[type="file"],
        .form-container button {
            margin-top: 10px;
            margin-bottom: 15px;
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            box-sizing: border-box;
        }

        /* Upload Button */
        .upload-button {
            background-color: #8B4513; /* Saddle brown */
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .upload-button:hover {
            background-color: #7a3b12; /* Darker brown for hover */
        }

        .section-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 15px;
            color: #5C4033; /* Dark brown */
        }

        /* Materials Table */
        .materials-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }

        .materials-table th, .materials-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .materials-table th {
            background-color: #d2b48c; /* Tan */
            font-weight: bold;
            color: #5C4033; /* Dark brown */
        }

        /* Delete Button */
        .delete-button {
            background-color: #A52A2A; /* Brownish red */
            color: #fff;
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .delete-button:hover {
            background-color: #8B0000; /* Dark red */
        }

        /* Info Text */
        .info-text {
            font-size: 14px;
            color: #5C4033; /* Dark brown */
            margin-top: 10px;
        }
</style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>Učitelj</h2>
            <ul>
                <li><a href="teacher_dashboard.php"><i class="icon">&#x1F4C8;</i> Nadzorna plošča</a></li>
                <li><a href="teacher_materials.php" class="active"><i class="icon">&#x1F4D6;</i> Gradivo</a></li>
                <li><a href="teacher_assignments.php"><i class="icon">&#x1F4C4;</i> Oddane naloge</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="section-header">Gradivo - Upravljanje</div>

            <div class="form-container">
                <label for="subject">Izberite predmet:</label>
                <select id="subject" name="subject">
                    <?php foreach ($subjects as $subject): ?>
                        <option value="<?php echo htmlspecialchars($subject); ?>"><?php echo htmlspecialchars($subject); ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="file">Naloži datoteko:</label>
                <input type="file" id="file" name="file">

                <button class="upload-button">Naloži gradivo</button>
                <p class="info-text">Izberite predmet in datoteko, nato kliknite "Naloži gradivo".</p>
            </div>

            <div class="section-title">Obstoječe gradivo</div>
            <table class="materials-table">
                <thead>
                    <tr>
                        <th>Predmet</th>
                        <th>Ime datoteke</th>
                        <th>Dejanje</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Replace with dynamic content -->
                    <tr>
                        <td>Mathematics</td>
                        <td>Algebra_Lesson_1.pdf</td>
                        <td><button class="delete-button">Izbriši</button></td>
                    </tr>
                    <tr>
                        <td>Physics</td>
                        <td>Newton_Laws.pptx</td>
                        <td><button class="delete-button">Izbriši</button></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
